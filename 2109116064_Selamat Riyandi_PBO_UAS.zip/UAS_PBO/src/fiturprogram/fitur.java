package fiturprogram;

import java.sql.SQLException;
import database.koneksidatabase;

public class fitur extends koneksidatabase {
    
    
    public fitur() throws ClassNotFoundException, SQLException {
        super();
    }

//Syntax Insert ================================================================
    public void insertdata(String nama, String divisi, String jobdesk) throws SQLException {
        String sql = String.format("INSERT INTO pegawai (Nama,ID_Divisi,Status) VALUE ('%s','%s','%s')",
        nama, divisi,jobdesk);
        this.setQuery(sql);
        this.execute();
    }

//Syntax Show Pegawai ==========================================================
    public void getdatapegawai() throws SQLException {
        String sql = "SELECT * FROM pegawai;";
        this.setQuery(sql);
        this.fetch();
    }
    
//Syntax Show Pegawai ==========================================================
    public void getdatadivisi() throws SQLException {
        String sql = "SELECT * FROM divisi;";
        this.setQuery(sql);
        this.fetch();
    }
    
//Syntax cari ID ===============================================================
    public void getid() throws SQLException {
    String sql = "SELECT id FROM pegawai";
    this.setQuery(sql);
    this.fetch();
    }
    
//Syntax Delete ================================================================
    public void deletedata(int id) throws SQLException {
        String sql = String.format("DELETE FROM pegawai WHERE ID = %d", id);
        this.setQuery(sql);
        this.execute();
    }

//Show Tabel Pegawai ===========================================================
    public String[][] showdatapegawai(boolean display_number) throws SQLException {
        String[][] data = new String[this.lendata()][4];
        getdatapegawai();
        this.fetch();
        int i = 0;
        while (this.value.next()) {
            if(display_number){
            data[i][0] =  Integer.toString(i+1);
            }
            else{data[i][0] =  Integer.toString(this.value.getInt("ID"));}
            data[i][1] = this.value.getString("Nama");
            data[i][2] = this.value.getString("ID_Divisi");
            data[i][3] = this.value.getString("Status");
            i++;
        }
        return data;
    }

//Show Tabel Pegawai ===========================================================
    public String[][] showdatadivisi(boolean display_number) throws SQLException {
        String[][] data = new String[this.lendata()][4];
        getdatadivisi();
        this.fetch();
        int i = 0;
        while (this.value.next()) {
            data[i][0] =  this.value.getString("ID_Divisi");
            data[i][1] = this.value.getString("Nama_Divisi");
            i++;
        }
        return data;
    }
    
    public int lendata() throws SQLException {
        getdatadivisi();
        this.fetch();
        int i = 0;
        while (this.value.next()) {
            i++;
        }
        return i;
    }
}
