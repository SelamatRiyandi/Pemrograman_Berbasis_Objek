package main;

import fiturprogram.fitur;
import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import database.*;

public class updatedata extends javax.swing.JFrame {
    fitur data_pegawai;

    public updatedata() throws ClassNotFoundException, SQLException {
        data_pegawai = new fitur();
        initComponents();
        this.showData();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        updatedivisipegawai = new javax.swing.JComboBox<>();
        updatestatuspegawai = new javax.swing.JComboBox<>();
        updatenamapegawai = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        tabeldatapegawai = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        updatebutton = new javax.swing.JButton();
        cancelbutton = new javax.swing.JButton();
        updateidpegawai = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(153, 153, 255));

        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("ID Pegawai     :");

        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Pilih baris record pada tabel untuk menentukan data yang akan diubah          :");

        updatedivisipegawai.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ADM", "FNC", "OPR", "PRM", "HRD" }));

        updatestatuspegawai.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Junior Staff", "Senior Staff", "Manager", "Interns" }));

        updatenamapegawai.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updatenamapegawaiActionPerformed(evt);
            }
        });

        tabeldatapegawai.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tabeldatapegawai.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabeldatapegawaiMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tabeldatapegawai);

        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Nama              :");

        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Divisi               :");

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Status              :");

        updatebutton.setText("Update");
        updatebutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updatebuttonActionPerformed(evt);
            }
        });

        cancelbutton.setBackground(new java.awt.Color(0, 102, 204));
        cancelbutton.setForeground(new java.awt.Color(255, 255, 255));
        cancelbutton.setText("Back");
        cancelbutton.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        cancelbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelbuttonActionPerformed(evt);
            }
        });

        updateidpegawai.setEditable(false);
        updateidpegawai.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateidpegawaiActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Employee data recording application");

        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("_______________________________________________________________");

        jLabel8.setText("Hopes Insurance Human Resource Development");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(40, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel7)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel3))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(updatenamapegawai)
                                    .addComponent(updatebutton, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(updatedivisipegawai, 0, 1, Short.MAX_VALUE)
                                    .addComponent(updatestatuspegawai, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jLabel5)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addGap(18, 18, 18)
                                .addComponent(updateidpegawai, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(24, 24, 24))
                    .addComponent(cancelbutton, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel9)
                .addGap(3, 3, 3)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 44, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(updateidpegawai, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(updatenamapegawai, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(updatedivisipegawai, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(updatestatuspegawai, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(updatebutton)
                .addGap(18, 18, 18)
                .addComponent(cancelbutton)
                .addGap(12, 12, 12))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    private void tabeldatapegawaiMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabeldatapegawaiMouseClicked
        int baris = tabeldatapegawai.rowAtPoint(evt.getPoint());
        
        String id = tabeldatapegawai.getValueAt(baris, 0).toString();
        updateidpegawai.setText(id);
        
        String nama = tabeldatapegawai.getValueAt(baris, 1).toString();
        updatenamapegawai.setText(nama);
        
        updatedivisipegawai.setSelectedItem(tabeldatapegawai.getValueAt(baris, 2).toString());
        updatedivisipegawai.getSelectedItem().toString();
        
        updatestatuspegawai.setSelectedItem(tabeldatapegawai.getValueAt(baris, 3).toString());
        updatestatuspegawai.getSelectedItem().toString();
        
    }//GEN-LAST:event_tabeldatapegawaiMouseClicked

    private void cancelbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelbuttonActionPerformed
        try {
            mainmenu cancel = new mainmenu();
            cancel.setVisible(true);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(mainmenu.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(mainmenu.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.dispose();
    }//GEN-LAST:event_cancelbuttonActionPerformed

    private void updatebuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updatebuttonActionPerformed
        if(updatenamapegawai.getText().equals("")){
            JOptionPane.showMessageDialog(null, "Nama tidak boleh kosong!");
        }
        else{
        try{
            String sql = "UPDATE pegawai SET ID='"+updateidpegawai.getText()+
                                         "',Nama='"+updatenamapegawai.getText()+
                                         "',ID_Divisi='"+updatedivisipegawai.getSelectedItem()+
                                         "',Status='"+updatestatuspegawai.getSelectedItem()+
                                         "' WHERE ID='"+updateidpegawai.getText()+"'";
            java.sql.Connection conn = (Connection)koneksidatabasefiturupdate.configDB();
            java.sql.PreparedStatement pstm = conn.prepareStatement(sql);
            pstm.execute();
            JOptionPane.showMessageDialog(null, "Data karyawan berhasil diperbarui");
        }catch(HeadlessException | SQLException e){
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
        try {
            this.showData();
        } catch (SQLException ex) {
            Logger.getLogger(updatedata.class.getName()).log(Level.SEVERE, null, ex);
        }}
    }//GEN-LAST:event_updatebuttonActionPerformed

    private void updateidpegawaiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateidpegawaiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_updateidpegawaiActionPerformed

    private void updatenamapegawaiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updatenamapegawaiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_updatenamapegawaiActionPerformed

    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new updatedata().setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(updatedata.class.getName()).log(Level.SEVERE, null, ex);
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(updatedata.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }
    public void showData() throws SQLException {
        tabeldatapegawai.setModel(new javax.swing.table.DefaultTableModel( data_pegawai.showdatapegawai(false),
        new String [] {"ID", "Nama", "Divisi", "Jobdesk"}));
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cancelbutton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable tabeldatapegawai;
    private javax.swing.JButton updatebutton;
    private javax.swing.JComboBox<String> updatedivisipegawai;
    private javax.swing.JTextField updateidpegawai;
    private javax.swing.JTextField updatenamapegawai;
    private javax.swing.JComboBox<String> updatestatuspegawai;
    // End of variables declaration//GEN-END:variables

    private void showdata() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
